This script will:

- create an FTP script that logs you in to the FTP server and download netcat

- delete the FTP script file

- run netcat in daemon mode

- run cmd.exe one more time to conceal the command we used in the run history.

Fill in the required information where you see the brackets.