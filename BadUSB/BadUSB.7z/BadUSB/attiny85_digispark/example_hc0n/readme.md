Script used for H-c0n Conference
