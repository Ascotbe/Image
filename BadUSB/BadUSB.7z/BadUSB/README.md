Some BadUSB attack examples
===========================
 
This repository have some BadUSB attack examples for Arduino IDE compatible devices

Devices that can be used:
* Digistump Digispark (Attiny85)
* Arduino Leonardo (Atmega32u4)
* Arduino Micro (Atmega32u4)
* Chineese Arduino Leonardo clones (Atmega32u4)
* Teensy 2.0 (Atmega32u4)
* Phoenix Ovipositor (Atmega32u4)
 
Download and installation
=========================
* Click "Clone or download" -> "Download ZIP"
* Unzip downloaded file where you want

Each directory contains its corresponding sketch files and comments.

Use
===
Each .ino file contains instuctions and needed libraries.

Version History
===============
```
(Date format: dd/mm/yyyy)
* 26/9/2017 Uninstall AVG and download file example
* 9/7/2017 First commit

```

TO DO
=====
- More examples


Contact
=======
Open an issue or feel free to ask us on twitter to [@JoelSernaMoreno](https://www.twitter.com/JoelSernaMoreno/) , [@ernesto_xload](https://www.twitter.com/ernesto_xload/)
