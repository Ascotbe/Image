Some of this scripts aren't prove yet. You must to know that this mean many hours of work for only one person. By the way, If you find some error on the code or any script which dont work, you can contact me and I will resolve It 

Here are some models of the script in this link: https://github.com/hak5darren/USB-Rubber-Ducky/wiki/Payloads

If you have any problem, send me a message and I would glad to help you.

Contact: https://twitter.com/JoelSernaMoreno

Bonus Track in this article: 
https://thehackerway.com/2017/09/05/vuelve-el-patito-low-cost-ahora-grazna-como-un-usb-rubber-ducky-original/

https://thehackerway.com/2017/09/05/get-back-the-low-cost-duck-now-squawks-like-an-original-usb-rubber-ducky/
